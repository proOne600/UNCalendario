module.exports = require('./utils/lifecycle-cmd.js')('stop')
;
