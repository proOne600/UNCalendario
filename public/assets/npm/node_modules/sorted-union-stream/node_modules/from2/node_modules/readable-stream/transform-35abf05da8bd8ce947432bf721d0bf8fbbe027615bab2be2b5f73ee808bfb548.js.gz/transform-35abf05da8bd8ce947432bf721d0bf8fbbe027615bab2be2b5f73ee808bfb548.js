module.exports = require("./lib/_stream_transform.js")
;
