'use strict'

module.exports = require('./registry')
;
