'use strict'

module.exports = require('./git')
;
