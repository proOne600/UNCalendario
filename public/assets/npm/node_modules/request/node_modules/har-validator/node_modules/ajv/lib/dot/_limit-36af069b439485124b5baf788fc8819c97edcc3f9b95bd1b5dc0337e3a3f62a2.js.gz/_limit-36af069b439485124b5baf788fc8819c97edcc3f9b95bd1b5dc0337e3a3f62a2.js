(function() { this.JST || (this.JST = {}); this.JST["npm/node_modules/request/node_modules/har-validator/node_modules/ajv/lib/dot/_limit"] = {{# def.definitions }}
  {{# def.errors }}
  {{# def.setupKeyword }}
  {{# def.$data }}
  
  {{
    var $isMax = $keyword == 'maximum'
      , $exclusiveKeyword = $isMax ? 'exclusiveMaximum' : 'exclusiveMinimum'
      , $schemaExcl = it.schema[$exclusiveKeyword]
      , $isDataExcl = it.opts.v5 && $schemaExcl && $schemaExcl.$data
      , $op = $isMax ? '<' : '>'
      , $notOp = $isMax ? '>' : '<';
  }}
  
  {{? $isDataExcl }}
    {{
      var $schemaValueExcl = it.util.getData($schemaExcl.$data, $dataLvl, it.dataPathArr)
        , $exclusive = 'exclusive' + $lvl
        , $opExpr = 'op' + $lvl
        , $opStr = '\' + ' + $opExpr + ' + \'';
    }}
    var schemaExcl{{=$lvl}} = {{=$schemaValueExcl}};
    {{ $schemaValueExcl = 'schemaExcl' + $lvl; }}
  
    var exclusive{{=$lvl}};
    if (typeof {{=$schemaValueExcl}} != 'boolean' && typeof {{=$schemaValueExcl}} != 'undefined') {
      {{ var $errorKeyword = $exclusiveKeyword; }}
      {{# def.error:'_exclusiveLimit' }}
    } else if({{# def.$dataNotType:'number' }}
              ((exclusive{{=$lvl}} = {{=$schemaValueExcl}} === true)
                ? {{=$data}} {{=$notOp}}= {{=$schemaValue}}
                : {{=$data}} {{=$notOp}} {{=$schemaValue}})
              || {{=$data}} !== {{=$data}}) {
      var op{{=$lvl}} = exclusive{{=$lvl}} ? '{{=$op}}' : '{{=$op}}=';
  {{??}}
    {{
      var $exclusive = $schemaExcl === true
        , $opStr = $op;  /*used in error*/
      if (!$exclusive) $opStr += '=';
      var $opExpr = '\'' + $opStr + '\''; /*used in error*/
    }}
  
    if ({{# def.$dataNotType:'number' }}
        {{=$data}} {{=$notOp}}{{?$exclusive}}={{?}} {{=$schemaValue}}
        || {{=$data}} !== {{=$data}}) {
  {{?}}
      {{ var $errorKeyword = $keyword; }}
      {{# def.error:'_limit' }}
    } {{? $breakOnError }} else { {{?}};
}).call(this);
